import pygame
import sys
from snake import Snake, CELL_SIZE
from food import Food
from config import load_config, update_high_score

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (50, 50, 50)

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

class Game:
    def __init__(self, grid_width=30, grid_height=20, fps=10):
        pygame.init()
        # Cargar configuración desde archivo
        config = load_config()
        self.grid_width = config.get("grid_width", grid_width)
        self.grid_height = config.get("grid_height", grid_height)
        self.fps = config.get("fps", fps)
        self.high_score = config.get("high_score", 0)
        
        self.cell_size = CELL_SIZE
        self.screen = pygame.display.set_mode((self.grid_width*CELL_SIZE, self.grid_height*CELL_SIZE))
        pygame.display.set_caption("Snake - Juego")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 28)
        self.reset()

    def reset(self):
        start_x = self.grid_width // 2
        start_y = self.grid_height // 2
        self.snake = Snake(start_x, start_y)
        self.food = Food(self.snake, self.grid_width, self.grid_height)
        self.score = 0
        self.game_over = False
        self.speed = self.fps

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_r and self.game_over:
                    self.reset()
                if event.key in (pygame.K_UP, pygame.K_w):
                    self.snake.set_direction(UP)
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    self.snake.set_direction(DOWN)
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    self.snake.set_direction(LEFT)
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.snake.set_direction(RIGHT)

    def update(self):
        if self.game_over:
            return
        self.snake.update()
        head_x, head_y = self.snake.head()

        if head_x < 0 or head_x >= self.grid_width or head_y < 0 or head_y >= self.grid_height:
            self.game_over = True
        elif self.snake.collided_with_self():
            self.game_over = True
        elif self.food.position and self.snake.head() == self.food.position:
            self.snake.grow()
            self.score += 1
            self.food.place(self.snake)
            if self.score % 5 == 0:
                self.speed += 1
            # Actualizar puntuación máxima
            if self.score > self.high_score:
                self.high_score = update_high_score(self.score)

    def draw_grid(self):
        for x in range(0, self.grid_width * CELL_SIZE, CELL_SIZE):
            pygame.draw.line(self.screen, GRAY, (x, 0), (x, self.grid_height * CELL_SIZE))
        for y in range(0, self.grid_height * CELL_SIZE, CELL_SIZE):
            pygame.draw.line(self.screen, GRAY, (0, y), (self.grid_width * CELL_SIZE, y))

    def draw_score(self):
        text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(text, (8, 8))
        high_text = self.font.render(f"High Score: {self.high_score}", True, WHITE)
        self.screen.blit(high_text, (8, 40))

    def draw_game_over(self):
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.screen.blit(overlay, (0, 0))
        big_font = pygame.font.SysFont(None, 64)
        text = big_font.render("GAME OVER", True, WHITE)
        self.screen.blit(text, text.get_rect(center=self.screen.get_rect().center))
        small_font = pygame.font.SysFont(None, 28)
        t2 = small_font.render("Presiona R para reiniciar o ESC para salir", True, WHITE)
        r2 = t2.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2 + 40))
        self.screen.blit(t2, r2)

    def run(self):
        while True:
            self.handle_events()
            self.update()
            self.screen.fill(BLACK)
            self.draw_grid()
            self.food.draw(self.screen)
            self.snake.draw(self.screen)
            self.draw_score()
            if self.game_over:
                self.draw_game_over()
            pygame.display.flip()
            self.clock.tick(self.speed)
