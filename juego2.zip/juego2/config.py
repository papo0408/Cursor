import json
import os

# Ejemplo de cómo leer y escribir archivos JSON
def load_config():
    """Carga la configuración desde un archivo JSON"""
    config_file = "config.json"
    default_config = {
        "high_score": 0,
        "grid_width": 30,
        "grid_height": 20,
        "fps": 10
    }
    
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default_config
    else:
        # Si no existe, crear el archivo con valores por defecto
        save_config(default_config)
        return default_config

def save_config(config):
    """Guarda la configuración en un archivo JSON"""
    config_file = "config.json"
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)

def update_high_score(score):
    """Actualiza la puntuación máxima si es mayor"""
    config = load_config()
    if score > config.get("high_score", 0):
        config["high_score"] = score
        save_config(config)
    return config.get("high_score", 0)






