import pygame

CELL_SIZE = 20
GREEN = (20, 160, 20)
DARK_GREEN = (10, 90, 10)
RIGHT = (1, 0)

class Snake:
    def __init__(self, x, y):
        self.segments = [(x, y), (x-1, y), (x-2, y)]
        self.direction = RIGHT
        self.grow_pending = 0

    def set_direction(self, dir_tuple):
        opposite = (-self.direction[0], -self.direction[1])
        if dir_tuple != opposite:
            self.direction = dir_tuple

    def update(self):
        head_x, head_y = self.segments[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)
        self.segments.insert(0, new_head)
        if self.grow_pending > 0:
            self.grow_pending -= 1
        else:
            self.segments.pop()

    def grow(self, amount=1):
        self.grow_pending += amount

    def head(self):
        return self.segments[0]

    def collided_with_self(self):
        return self.head() in self.segments[1:]

    def occupies(self, pos):
        return pos in self.segments

    def draw(self, surface):
        for i, (x, y) in enumerate(self.segments):
            rect = pygame.Rect(x*CELL_SIZE, y*CELL_SIZE, CELL_SIZE, CELL_SIZE)
            color = GREEN if i == 0 else DARK_GREEN
            pygame.draw.rect(surface, color, rect)
