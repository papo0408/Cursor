import pygame
import random
from snake import CELL_SIZE

RED = (200, 30, 30)

class Food:
    def __init__(self, snake, grid_width, grid_height):
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.position = (0, 0)
        self.place(snake)

    def place(self, snake):
        empty_cells = [
            (x, y)
            for x in range(self.grid_width)
            for y in range(self.grid_height)
            if not snake.occupies((x, y))
        ]
        if empty_cells:
            self.position = random.choice(empty_cells)
        else:
            self.position = None

    def draw(self, surface):
        if self.position:
            x, y = self.position
            rect = pygame.Rect(x*CELL_SIZE, y*CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(surface, RED, rect)
