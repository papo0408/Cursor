# Calcular el factorial de un número dado

def factorial(n):
    # Si n es 0 o 1, devolver 1 (caso base)
    if n == 0 or n == 1:
        return 1
    # En otro caso, devolver n * factorial(n-1)
    else:
        return n * factorial(n - 1)


# Ejemplos de uso
if __name__ == "__main__":
    # Ejemplo 1: Factorial de 0
    print(f"factorial(0) = {factorial(0)}")

    # Ejemplo 2: Factorial de 1
    print(f"factorial(1) = {factorial(1)}")

    # Ejemplo 3: Factorial de 5
    print(f"factorial(5) = {factorial(5)}")

    # Ejemplo 4: Factorial de 7
    print(f"factorial(7) = {factorial(7)}")

    # Ejemplo 5: Factorial de 10
    print(f"factorial(10) = {factorial(10)}")

    # Ejemplo 6: Factorial de 3
    resultado = factorial(3)
    print(f"factorial(3) = {resultado}")

    # Ejemplo 7: Usando la función en una expresión
    suma = factorial(4) + factorial(2)
    print(f"factorial(4) + factorial(2) = {suma}")

