"""
Ejemplos de cómo abrir y utilizar diferentes tipos de archivos en Python
"""

# ============================================
# 1. LEER ARCHIVOS DE TEXTO
# ============================================

def leer_archivo_texto(nombre_archivo):
    """Lee un archivo de texto completo"""
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as f:
            contenido = f.read()
        return contenido
    except FileNotFoundError:
        print(f"El archivo {nombre_archivo} no existe")
        return None

def leer_archivo_linea_por_linea(nombre_archivo):
    """Lee un archivo línea por línea"""
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as f:
            lineas = f.readlines()
        return [linea.strip() for linea in lineas]
    except FileNotFoundError:
        print(f"El archivo {nombre_archivo} no existe")
        return []

# ============================================
# 2. ESCRIBIR ARCHIVOS DE TEXTO
# ============================================

def escribir_archivo_texto(nombre_archivo, contenido):
    """Escribe contenido en un archivo de texto"""
    with open(nombre_archivo, 'w', encoding='utf-8') as f:
        f.write(contenido)

def agregar_a_archivo(nombre_archivo, contenido):
    """Agrega contenido al final de un archivo"""
    with open(nombre_archivo, 'a', encoding='utf-8') as f:
        f.write(contenido + '\n')

# ============================================
# 3. LEER ARCHIVOS JSON
# ============================================

import json

def leer_json(nombre_archivo):
    """Lee un archivo JSON"""
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as f:
            datos = json.load(f)
        return datos
    except FileNotFoundError:
        print(f"El archivo {nombre_archivo} no existe")
        return {}
    except json.JSONDecodeError:
        print(f"Error al leer el JSON en {nombre_archivo}")
        return {}

def escribir_json(nombre_archivo, datos):
    """Escribe datos en un archivo JSON"""
    with open(nombre_archivo, 'w', encoding='utf-8') as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)

# ============================================
# 4. LEER ARCHIVOS CSV
# ============================================

import csv

def leer_csv(nombre_archivo):
    """Lee un archivo CSV"""
    datos = []
    try:
        with open(nombre_archivo, 'r', encoding='utf-8', newline='') as f:
            lector = csv.DictReader(f)
            for fila in lector:
                datos.append(fila)
        return datos
    except FileNotFoundError:
        print(f"El archivo {nombre_archivo} no existe")
        return []

def escribir_csv(nombre_archivo, datos, encabezados):
    """Escribe datos en un archivo CSV"""
    with open(nombre_archivo, 'w', encoding='utf-8', newline='') as f:
        escritor = csv.DictWriter(f, fieldnames=encabezados)
        escritor.writeheader()
        escritor.writerows(datos)

# ============================================
# 5. VERIFICAR SI UN ARCHIVO EXISTE
# ============================================

import os

def archivo_existe(nombre_archivo):
    """Verifica si un archivo existe"""
    return os.path.exists(nombre_archivo)

# ============================================
# EJEMPLOS DE USO
# ============================================

if __name__ == "__main__":
    # Ejemplo 1: Leer un archivo de texto
    contenido = leer_archivo_texto("ejemplo.txt")
    if contenido:
        print("Contenido del archivo:", contenido)
    
    # Ejemplo 2: Escribir un archivo JSON
    datos = {
        "nombre": "Jugador",
        "puntuacion": 100,
        "nivel": 5
    }
    escribir_json("datos_jugador.json", datos)
    
    # Ejemplo 3: Leer el JSON que acabamos de escribir
    datos_leidos = leer_json("datos_jugador.json")
    print("Datos leídos:", datos_leidos)






